void plot(){

  // opening files
  TFile f1("out_dat.root");
  TFile f2("out_sig.root");
  TFile f3("out_bkg.root");

  // get histograms from the files
  TH1F * h_n_1 = (TH1F*)f1.Get("h_nparticles");
  TH1F * h_n_2 = (TH1F*)f2.Get("h_nparticles");
  TH1F * h_n_3 = (TH1F*)f3.Get("h_nparticles");
  
  // set line colors
  h_n_1->SetLineColor(1);
  h_n_2->SetLineColor(2);
  h_n_3->SetLineColor(3);
  
  TH1F * h_x_1 = (TH1F*)f1.Get("h_x");
  TH1F * h_x_2 = (TH1F*)f2.Get("h_x");
  TH1F * h_x_3 = (TH1F*)f3.Get("h_x");
  h_x_1->SetLineColor(1);
  h_x_2->SetLineColor(2);
  h_x_3->SetLineColor(3);
  
  TH1F * h_x_y_1 = (TH1F*)f1.Get("h_x_y");
  TH1F * h_x_y_2 = (TH1F*)f2.Get("h_x_y");
  TH1F * h_x_y_3 = (TH1F*)f3.Get("h_x_y");

  TCanvas c; 
  c.SaveAs("plots.pdf["); // opening pdf

  // draw all histograms
  h_n_1->Draw("e");
  h_n_2->Draw("same");
  h_n_3->Draw("same");

  c.SaveAs("plots.pdf"); // plot

  // next plot
  h_x_1->Draw("e");
  h_x_2->Draw("same");
  h_x_3->Draw("same");
  c.SaveAs("plots.pdf");

  // next plot
  c.Clear();
  c.Divide(3);
  c.cd(1); h_x_y_1->Draw("colz");
  c.cd(2); h_x_y_2->Draw("colz");
  c.cd(3); h_x_y_3->Draw("colz");
  c.SaveAs("plots.pdf");

  c.SaveAs("plots.pdf]"); // closing pdf
}
